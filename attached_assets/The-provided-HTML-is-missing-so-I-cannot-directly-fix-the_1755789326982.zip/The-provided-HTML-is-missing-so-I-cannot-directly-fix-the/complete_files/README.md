# MyExtraToYou - BooksForAll

A comprehensive book donation and marketplace platform where users can donate books to a centralized database and others can browse, request, and buy/reject them. The platform includes user authentication, centralized product visibility, email notifications, user rating system with star points, account moderation, and buy/reject transaction logic.

## Features

### 🔐 User Authentication
- Simple registration with name, location, mobile, email, password
- Login/logout functionality with captcha verification
- User profile management with edit capabilities

### 📚 Book Donation System
- Add books with details: name, language, topic, price, location
- Optional image upload (up to 3 images)
- Quality rating system (1-5 stars)
- All donated books go to centralized database

### 🛒 Marketplace & Transactions
- **Centralized Goods Database**: All users can see donated books from others
- **Buy System**: Click "BUY NOW" → seller gets +1 star, email notification sent
- **Reject System**: After purchase, "BUY" changes to "REJECT" with feedback form
- **Email Notifications**: All transactions send emails to seller and CC abhirampanicker@gmail.com

### ⭐ Rating & Moderation System
- Sellers gain +1 star for each purchase
- Sellers lose -1 star for each rejection
- Account gets banned after 5+ rejections
- Banned users' products are hidden from marketplace

### 🎨 UI/UX Features
- Responsive design with light/dark theme toggle
- Navigation dropdown under user name when logged in
- Help system with MCQ support and custom problem reporting
- Clean product cards with seller information and ratings

## Technology Stack

### Frontend
- **HTML5 + CSS3**: Modern responsive design with CSS Grid and Flexbox
- **Vanilla JavaScript**: No frameworks, pure JavaScript for all interactions
- **Google Fonts**: Poppins font family for typography
- **Theme System**: Dynamic light/dark mode switching

### Backend
- **Node.js + Express**: RESTful API server
- **PostgreSQL**: Database with Drizzle ORM
- **Neon Database**: Serverless PostgreSQL hosting

### Key Dependencies
- `express` - Web framework
- `@neondatabase/serverless` - Database connection
- `drizzle-orm` - Database ORM
- `cors` - Cross-origin resource sharing
- `ws` - WebSocket support for Neon

## Database Schema

### Users Table
- Personal information, contact details
- Star rating system and rejection tracking
- Ban status and timestamps

### Products Table
- Book details with images (JSON array)
- Seller association and transaction status
- Quality ratings and pickup locations

### Transactions Table
- Purchase/rejection tracking
- Buyer-seller relationships
- Status management

### Additional Tables
- `emails` - Email notification tracking
- `rejections` - Detailed rejection feedback
- `help_requests` - User support system

## Installation & Setup

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd myextratoyou-booksforall
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up environment variables**
   ```bash
   DATABASE_URL=your_neon_database_url
   SENDGRID_API_KEY=your_sendgrid_api_key_optional
   ```

4. **Push database schema**
   ```bash
   npx drizzle-kit push
   ```

5. **Start the server**
   ```bash
   npm start
   ```

6. **Access the application**
   - Open http://localhost:5000 in your browser

## API Endpoints

### Users
- `POST /api/users` - Register/login user
- `GET /api/users/:email` - Get user by email
- `PUT /api/users/:id` - Update user profile

### Products
- `POST /api/products` - Create new product
- `GET /api/products` - Get all products with seller info
- `GET /api/products/user/:userId` - Get user's products
- `PUT /api/products/:id` - Update product
- `DELETE /api/products/:id` - Delete product

### Transactions
- `POST /api/transactions` - Handle buy/reject actions

### Utilities
- `POST /api/emails` - Email tracking
- `POST /api/help-requests` - Help system

## File Structure

```
├── complete_files/
│   ├── index.html              # Main frontend file
│   ├── app.js                  # Express server (in-memory storage)
│   ├── package.json            # Dependencies and scripts
│   ├── drizzle.config.js       # Database configuration
│   ├── shared/
│   │   └── schema.ts           # Database schema definitions
│   ├── server/
│   │   ├── db.ts               # Database connection
│   │   └── api.js              # Database-powered API endpoints
│   └── README.md               # This file
```

## Key Features Implementation

### Centralized Goods Database
- All donated books are stored in PostgreSQL database
- Users cannot see their own products in "Check for Goods" section
- Banned sellers' products are automatically hidden

### Buy/Reject Transaction Flow
1. User sees product in "Check for Goods"
2. Clicks "BUY NOW" → creates transaction, emails seller, +1 star
3. After purchase, button changes to "REJECT"
4. Rejection opens feedback form with reasons
5. Rejection processed → -1 star, rejection count incremented
6. 5+ rejections → account banned, products hidden

### Email Notification System
- Purchase notifications to seller with buyer contact info
- CC to abhirampanicker@gmail.com for all transactions
- Rejection feedback emails to admin with full details
- Help requests forwarded to support team

### User Experience
- Clean, intuitive interface with modern design
- Responsive across desktop and mobile devices
- Dark/light theme preference persistence
- Smooth animations and transitions

## Future Enhancements

- Real email integration with SendGrid
- Image upload to cloud storage
- Advanced search and filtering
- User messaging system
- Transaction history dashboard
- Admin panel for moderation
- Payment gateway integration
- Mobile app development

## Contributing

1. Fork the repository
2. Create feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit changes (`git commit -m 'Add AmazingFeature'`)
4. Push to branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## Credits

**MyExtraToYou - BooksForAll** is brought to you by:
- **Krunal Patil** - Concept & Development
- **Abhiram Panicker** - UI Design

Special thanks to all contributors and the open-source community!

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For support, email abhirampanicker@gmail.com or use the in-app help system.