const express = require('express');
const path = require('path');

const app = express();
const port = 5000;

// Middleware
app.use(express.json());
app.use(express.static('.'));

// In-memory storage for development (can be replaced with database)
let users = [];
let products = [];
let transactions = [];
let emails = [];
let helpRequests = [];

// Helper functions
function findUserByEmail(email) {
  return users.find(u => u.email === email);
}

// Users endpoints
app.post('/api/users', (req, res) => {
  try {
    const { name, email, password, mobile, state, district, action } = req.body;
    
    console.log('User request:', { action, email, name });
    
    let user = findUserByEmail(email);
    
    if (action === 'login') {
      if (user && user.password === password) {
        res.json({ success: true, user, message: 'Login successful' });
      } else {
        res.json({ success: false, message: 'Invalid credentials' });
      }
    } else if (action === 'register') {
      if (user) {
        res.json({ success: false, message: 'User already exists' });
      } else {
        user = {
          id: Date.now().toString(),
          name,
          email,
          password,
          mobile,
          state,
          district,
          stars: 0,
          rejections: 0,
          banned: false,
          createdAt: new Date().toISOString()
        };
        users.push(user);
        res.json({ success: true, user, message: 'Registration successful' });
      }
    } else {
      // Auto-detect based on existing user
      if (user && user.password === password) {
        res.json({ success: true, user, message: 'Login successful' });
      } else if (!user) {
        user = {
          id: Date.now().toString(),
          name,
          email,
          password,
          mobile,
          state,
          district,
          stars: 0,
          rejections: 0,
          banned: false,
          createdAt: new Date().toISOString()
        };
        users.push(user);
        res.json({ success: true, user, message: 'Registration successful' });
      } else {
        res.json({ success: false, message: 'Invalid credentials' });
      }
    }
  } catch (error) {
    console.error('User endpoint error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

app.put('/api/users', (req, res) => {
  try {
    const updatedUser = req.body;
    const userIndex = users.findIndex(u => u.id === updatedUser.id);
    
    if (userIndex !== -1) {
      users[userIndex] = { ...users[userIndex], ...updatedUser, updatedAt: new Date().toISOString() };
      res.json({ success: true, user: users[userIndex] });
    } else {
      res.status(404).json({ success: false, error: 'User not found' });
    }
  } catch (error) {
    console.error('User update error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// Products endpoints
app.post('/api/products', (req, res) => {
  try {
    const { name, language, topic, price, rating, place, images, sellerId } = req.body;
    
    console.log('Product creation:', { name, sellerId });
    
    const product = {
      id: Date.now().toString(),
      name,
      language,
      topic,
      price: parseInt(price),
      rating: parseInt(rating),
      place,
      images: Array.isArray(images) ? images : [],
      sellerId: sellerId.toString(),
      status: 'active',
      createdAt: new Date().toISOString()
    };
    
    products.push(product);
    res.json({ success: true, product });
  } catch (error) {
    console.error('Product creation error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

app.get('/api/products', (req, res) => {
  try {
    // Get products with seller information
    const productsWithSellers = products.map(product => {
      const seller = users.find(u => u.id === product.sellerId);
      return {
        ...product,
        seller: seller ? {
          id: seller.id,
          name: seller.name,
          email: seller.email,
          mobile: seller.mobile,
          state: seller.state,
          district: seller.district,
          stars: seller.stars || 0,
          banned: seller.banned || false
        } : null
      };
    }).filter(product => product.seller !== null);

    console.log('Products fetch:', { count: productsWithSellers.length });
    res.json({ success: true, products: productsWithSellers });
  } catch (error) {
    console.error('Products fetch error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

app.get('/api/products/user/:userId', (req, res) => {
  try {
    const { userId } = req.params;
    const userProducts = products.filter(p => p.sellerId === userId);
    res.json({ success: true, products: userProducts });
  } catch (error) {
    console.error('User products fetch error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

app.delete('/api/products/:id', (req, res) => {
  try {
    const { id } = req.params;
    const productIndex = products.findIndex(p => p.id === id);
    
    if (productIndex !== -1) {
      products.splice(productIndex, 1);
      res.json({ success: true, message: 'Product deleted' });
    } else {
      res.status(404).json({ success: false, error: 'Product not found' });
    }
  } catch (error) {
    console.error('Product deletion error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// Transactions endpoints
app.post('/api/transactions', (req, res) => {
  try {
    const { productId, sellerId, buyerId, action, reason, details } = req.body;
    
    console.log('Transaction:', { productId, sellerId, buyerId, action });
    
    if (action === 'buy') {
      // Handle purchase
      const transaction = {
        id: Date.now().toString(),
        productId,
        sellerId,
        buyerId,
        status: 'purchased',
        createdAt: new Date().toISOString()
      };
      
      transactions.push(transaction);
      
      // Update seller stars
      const sellerIndex = users.findIndex(u => u.id === sellerId);
      if (sellerIndex !== -1) {
        users[sellerIndex].stars = (users[sellerIndex].stars || 0) + 1;
      }
      
      // Update product status
      const productIndex = products.findIndex(p => p.id === productId);
      if (productIndex !== -1) {
        products[productIndex].status = 'purchased';
        products[productIndex].buyerId = buyerId;
      }
      
      // Store email notification
      const seller = users.find(u => u.id === sellerId);
      const buyer = users.find(u => u.id === buyerId);
      const product = products.find(p => p.id === productId);
      
      if (seller && buyer && product) {
        const email = {
          id: Date.now().toString(),
          toEmail: seller.email,
          ccEmail: 'abhirampanicker@gmail.com',
          subject: 'New Purchase Request - MyExtraToYou',
          body: `Hello ${seller.name},

Great news! ${buyer.name} is interested in purchasing your book "${product.name}".

Product Details:
- Book: ${product.name}
- Price: ₹${product.price}
- Language: ${product.language}
- Topic: ${product.topic}

Buyer Contact:
- Name: ${buyer.name}
- Email: ${buyer.email}
- Phone: ${buyer.mobile}
- Location: ${buyer.state}, ${buyer.district}

Please contact the buyer directly to arrange the transaction.

Best regards,
MyExtraToYou Team`,
          sent: true,
          sentAt: new Date().toISOString()
        };
        emails.push(email);
      }
      
      res.json({ success: true, transaction });
    } 
    else if (action === 'reject') {
      // Handle rejection
      const rejection = {
        id: Date.now().toString(),
        productId,
        sellerId,
        buyerId,
        reason,
        details,
        createdAt: new Date().toISOString()
      };
      
      // Update seller stats
      const sellerIndex = users.findIndex(u => u.id === sellerId);
      if (sellerIndex !== -1) {
        users[sellerIndex].stars = Math.max(0, (users[sellerIndex].stars || 0) - 1);
        users[sellerIndex].rejections = (users[sellerIndex].rejections || 0) + 1;
        
        // Ban if 5+ rejections
        const shouldBan = users[sellerIndex].rejections >= 5;
        if (shouldBan) {
          users[sellerIndex].banned = true;
          users[sellerIndex].banDate = new Date().toISOString();
        }
      }
      
      // Update product status
      const productIndex = products.findIndex(p => p.id === productId);
      if (productIndex !== -1) {
        products[productIndex].status = 'rejected';
        products[productIndex].rejectedBy = buyerId;
      }
      
      // Send admin email
      const seller = users.find(u => u.id === sellerId);
      const buyer = users.find(u => u.id === buyerId);
      const product = products.find(p => p.id === productId);
      
      if (seller && buyer && product) {
        const email = {
          id: Date.now().toString(),
          toEmail: 'abhirampanicker@gmail.com',
          subject: 'Product Rejection Feedback - MyExtraToYou',
          body: `Product Rejection Feedback

Seller: ${seller.name} (${seller.email})
Product: ${product.name}
Rejected by: ${buyer.name} (${buyer.email})

Reason: ${reason}
Details: ${details}

Seller Stats:
- Current Stars: ${seller.stars || 0}
- Total Rejections: ${seller.rejections || 0}
- Account Status: ${seller.banned ? 'BANNED' : 'Active'}

Transaction Date: ${new Date().toLocaleString()}

---
MyExtraToYou Admin Panel`,
          sent: true,
          sentAt: new Date().toISOString()
        };
        emails.push(email);
      }
      
      res.json({ 
        success: true, 
        rejection, 
        sellerBanned: users.find(u => u.id === sellerId)?.banned || false 
      });
    }
    else {
      res.status(400).json({ success: false, message: 'Invalid action' });
    }
  } catch (error) {
    console.error('Transaction error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// Health check
app.get('/api/health', (req, res) => {
  res.json({ success: true, message: 'MyExtraToYou API is running' });
});

// Debug endpoints
app.get('/api/debug/users', (req, res) => {
  res.json({ users: users.length, data: users });
});

app.get('/api/debug/products', (req, res) => {
  res.json({ products: products.length, data: products });
});

app.get('/api/debug/transactions', (req, res) => {
  res.json({ transactions: transactions.length, data: transactions });
});

app.get('/api/debug/emails', (req, res) => {
  res.json({ emails: emails.length, data: emails });
});

// Serve the main HTML file
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// Handle 404s
app.use((req, res) => {
  if (req.path.startsWith('/api/')) {
    res.status(404).json({ success: false, error: 'API endpoint not found' });
  } else {
    res.sendFile(path.join(__dirname, 'index.html'));
  }
});

app.listen(port, '0.0.0.0', () => {
  console.log(`MyExtraToYou - BooksForAll server running on port ${port}`);
  console.log('Features available:');
  console.log('- User registration and authentication');
  console.log('- Book donation and marketplace');
  console.log('- Transaction system with email notifications');
  console.log('- User rating and moderation system');
  console.log('- Help system with MCQ support');
});