import { pgTable, text, integer, timestamp, boolean, serial, varchar } from 'drizzle-orm/pg-core';
import { relations } from 'drizzle-orm';

// Users table
export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  name: varchar('name', { length: 255 }).notNull(),
  email: varchar('email', { length: 255 }).notNull().unique(),
  password: text('password').notNull(),
  mobile: varchar('mobile', { length: 15 }).notNull(),
  state: varchar('state', { length: 100 }).notNull(),
  district: varchar('district', { length: 100 }).notNull(),
  stars: integer('stars').default(0),
  rejections: integer('rejections').default(0),
  banned: boolean('banned').default(false),
  banDate: timestamp('ban_date'),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow()
});

// Products table
export const products = pgTable('products', {
  id: serial('id').primaryKey(),
  name: varchar('name', { length: 255 }).notNull(),
  language: varchar('language', { length: 100 }).notNull(),
  topic: varchar('topic', { length: 255 }).notNull(),
  price: integer('price').notNull(),
  rating: integer('rating').notNull(), // Book quality rating
  place: text('place').notNull(), // Pickup location
  images: text('images').notNull(), // JSON array of image URLs
  status: varchar('status', { length: 50 }), // 'purchased', 'rejected', null
  sellerId: integer('seller_id').notNull(),
  buyerId: integer('buyer_id'),
  rejectedBy: integer('rejected_by'),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow()
});

// Transactions table
export const transactions = pgTable('transactions', {
  id: serial('id').primaryKey(),
  productId: integer('product_id').notNull(),
  sellerId: integer('seller_id').notNull(),
  buyerId: integer('buyer_id').notNull(),
  status: varchar('status', { length: 50 }).notNull(), // 'purchased', 'rejected'
  createdAt: timestamp('created_at').defaultNow()
});

// Emails table (for tracking sent emails)
export const emails = pgTable('emails', {
  id: serial('id').primaryKey(),
  toEmail: varchar('to_email', { length: 255 }).notNull(),
  ccEmail: varchar('cc_email', { length: 255 }),
  subject: text('subject').notNull(),
  body: text('body').notNull(),
  sent: boolean('sent').default(true),
  createdAt: timestamp('created_at').defaultNow()
});

// Rejections table (for tracking rejection feedback)
export const rejections = pgTable('rejections', {
  id: serial('id').primaryKey(),
  productId: integer('product_id').notNull(),
  sellerId: integer('seller_id').notNull(),
  buyerId: integer('buyer_id').notNull(),
  reason: varchar('reason', { length: 100 }).notNull(),
  details: text('details'),
  createdAt: timestamp('created_at').defaultNow()
});

// Help requests table
export const helpRequests = pgTable('help_requests', {
  id: serial('id').primaryKey(),
  userId: integer('user_id'),
  problemType: varchar('problem_type', { length: 100 }).notNull(),
  problemTitle: varchar('problem_title', { length: 255 }).notNull(),
  problemDetails: text('problem_details'),
  userAgent: text('user_agent'),
  resolved: boolean('resolved').default(false),
  createdAt: timestamp('created_at').defaultNow()
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  products: many(products),
  transactions: many(transactions),
  helpRequests: many(helpRequests)
}));

export const productsRelations = relations(products, ({ one, many }) => ({
  seller: one(users, {
    fields: [products.sellerId],
    references: [users.id]
  }),
  buyer: one(users, {
    fields: [products.buyerId],
    references: [users.id]
  }),
  transactions: many(transactions)
}));

export const transactionsRelations = relations(transactions, ({ one }) => ({
  product: one(products, {
    fields: [transactions.productId],
    references: [products.id]
  }),
  seller: one(users, {
    fields: [transactions.sellerId],
    references: [users.id]
  }),
  buyer: one(users, {
    fields: [transactions.buyerId],
    references: [users.id]
  })
}));

export const rejectionsRelations = relations(rejections, ({ one }) => ({
  product: one(products, {
    fields: [rejections.productId],
    references: [products.id]
  }),
  seller: one(users, {
    fields: [rejections.sellerId],
    references: [users.id]
  }),
  buyer: one(users, {
    fields: [rejections.buyerId],
    references: [users.id]
  })
}));

export const helpRequestsRelations = relations(helpRequests, ({ one }) => ({
  user: one(users, {
    fields: [helpRequests.userId],
    references: [users.id]
  })
}));

// Type exports
export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Product = typeof products.$inferSelect;
export type InsertProduct = typeof products.$inferInsert;
export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = typeof transactions.$inferInsert;
export type Email = typeof emails.$inferSelect;
export type InsertEmail = typeof emails.$inferInsert;
export type Rejection = typeof rejections.$inferSelect;
export type InsertRejection = typeof rejections.$inferInsert;
export type HelpRequest = typeof helpRequests.$inferSelect;
export type InsertHelpRequest = typeof helpRequests.$inferInsert;