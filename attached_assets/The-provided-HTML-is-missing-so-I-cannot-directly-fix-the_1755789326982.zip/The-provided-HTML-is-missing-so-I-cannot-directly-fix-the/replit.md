# MyExtraToYou - BooksForAll

## Overview

MyExtraToYou is a comprehensive book sharing platform with complete transaction management, user rating system, and email notifications. The platform enables users to donate books, browse available items, and conduct secure transactions with built-in seller ratings and moderation features. Users can purchase books through an integrated email system that notifies sellers and tracks all transactions.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes (August 20, 2025)

### Navigation System Enhancement
- User navigation items (Donate, Check for Goods, Edit Profile) properly hidden when not logged in
- Navigation items become visible only after successful user login
- Help button now only appears after user login for authenticated support access
- User profile displays name, stars, and logout button in top-right corner when logged in

### Backend Integration
- Migrated from static HTML to Node.js Express server with full API endpoints
- Database integration completed with PostgreSQL and Drizzle ORM setup
- API server running on port 5000 with comprehensive user, product, and transaction management
- Email notification system integrated for purchase requests and help submissions

### Transaction & Rating System
- **Buy System**: Users can click "BUY NOW" on products, which sends email to seller and cc to abhirampanicker@gmail.com
- **Rating System**: Sellers gain +1 star for each purchase, lose -1 star for each rejection
- **Rejection System**: After purchase, "BUY" button changes to "REJECT" with feedback form
- **Account Moderation**: Users with 5+ rejections get temporarily banned
- **Email Integration**: Simulated email system with localStorage storage and notifications

### Enhanced Product Management
- Products show seller ratings, contact details, and transaction status
- Banned sellers' products are hidden from marketplace
- Users cannot see their own products in "Check for Goods" section
- Product cards now include seller information and quality ratings

## System Architecture

### Frontend Architecture
- **Single Page Application (SPA)**: Built with vanilla HTML, CSS, and JavaScript
- **Responsive Design**: Mobile-first approach using CSS Grid and Flexbox
- **Theme System**: Dynamic light/dark mode switching with CSS custom properties
- **Modular CSS**: Uses CSS variables for consistent theming and easy maintenance
- **Component-Based Structure**: Navigation, modals, and forms are structured as reusable components

### Authentication System
- **Client-Side Form Validation**: Basic form validation with pattern matching for mobile numbers and email
- **CAPTCHA Integration**: Simple mathematical CAPTCHA system for bot prevention
- **User Registration Flow**: Collects name, location (state/district), mobile, email, and password
- **Modal-Based Login**: Clean overlay login experience without page navigation

### User Interface Design
- **Design System**: Uses Poppins font family for modern typography
- **Color Scheme**: Carefully crafted color variables for both light and dark themes
- **Interactive Elements**: Smooth transitions and hover effects throughout the interface
- **Accessibility Features**: Proper ARIA labels and semantic HTML structure

### File Organization
- **Separation of Concerns**: HTML structure, CSS styling, and JavaScript functionality are separated
- **Asset Management**: Dedicated folder structure for attached assets and resources
- **Modular JavaScript**: External script files for better code organization

## External Dependencies

### Frontend Libraries
- **Google Fonts**: Poppins font family for typography
- **Native Web APIs**: Uses modern browser APIs for theme switching and form handling

### Potential Backend Integration Points
- **User Authentication Service**: Ready for integration with backend authentication system
- **Database Connection**: Form structure suggests preparation for user data storage
- **Location Services**: State and district fields indicate potential geographic features

### Browser Compatibility
- **Modern Browser Features**: Uses CSS custom properties, CSS Grid, and modern JavaScript
- **Progressive Enhancement**: Graceful degradation for older browsers through fallback styles

The application is currently a frontend-only implementation that's architected to easily integrate with backend services for user management, book cataloging, and community features.