const express = require('express');
const cors = require('cors');
const { Pool } = require('@neondatabase/serverless');
const { drizzle } = require('drizzle-orm/neon-serverless');
const { eq, sql } = require('drizzle-orm');
const { users, products, transactions, emails, rejections, helpRequests } = require('../shared/schema.ts');

// Initialize database
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const db = drizzle(pool);

const app = express();
const port = 3000;

app.use(cors());
app.use(express.json());

// Users endpoints
app.post('/api/users', async (req, res) => {
  try {
    const { name, email, password, mobile, state, district } = req.body;
    
    // Check if user already exists
    const existingUser = await db.select().from(users).where(eq(users.email, email)).limit(1);
    
    if (existingUser.length > 0) {
      return res.json({ success: true, user: existingUser[0], message: 'User logged in' });
    }

    // Create new user
    const newUser = await db.insert(users).values({
      name,
      email,
      password,
      mobile,
      state,
      district,
      stars: 0,
      rejections: 0,
      banned: false
    }).returning();

    res.json({ success: true, user: newUser[0], message: 'User created' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.get('/api/users/:email', async (req, res) => {
  try {
    const { email } = req.params;
    const user = await db.select().from(users).where(eq(users.email, email)).limit(1);
    
    if (user.length === 0) {
      return res.status(404).json({ success: false, error: 'User not found' });
    }

    res.json({ success: true, user: user[0] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.put('/api/users/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const updates = req.body;
    
    const updatedUser = await db
      .update(users)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(users.id, parseInt(id)))
      .returning();

    res.json({ success: true, user: updatedUser[0] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Products endpoints
app.post('/api/products', async (req, res) => {
  try {
    const { name, language, topic, price, rating, place, images, sellerId } = req.body;
    
    const newProduct = await db.insert(products).values({
      name,
      language,
      topic,
      price: parseInt(price),
      rating: parseInt(rating),
      place,
      images: JSON.stringify(images),
      sellerId: parseInt(sellerId)
    }).returning();

    res.json({ success: true, product: newProduct[0] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.get('/api/products', async (req, res) => {
  try {
    const allProducts = await db
      .select()
      .from(products)
      .leftJoin(users, eq(products.sellerId, users.id));

    const formattedProducts = allProducts.map(row => ({
      ...row.products,
      images: JSON.parse(row.products.images || '[]'),
      seller: row.users
    }));

    res.json({ success: true, products: formattedProducts });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.put('/api/products/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const updates = req.body;
    
    const updatedProduct = await db
      .update(products)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(products.id, parseInt(id)))
      .returning();

    res.json({ success: true, product: updatedProduct[0] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.delete('/api/products/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    await db.delete(products).where(eq(products.id, parseInt(id)));
    
    res.json({ success: true, message: 'Product deleted' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Transactions endpoints
app.post('/api/transactions', async (req, res) => {
  try {
    const { productId, sellerId, buyerId, action, reason, details } = req.body;
    
    if (action === 'buy') {
      // Create purchase transaction
      const newTransaction = await db.insert(transactions).values({
        productId: parseInt(productId),
        sellerId: parseInt(sellerId),
        buyerId: parseInt(buyerId),
        status: 'purchased'
      }).returning();

      // Get product and seller details for email
      const product = await db.select().from(products).where(eq(products.id, parseInt(productId))).limit(1);
      const seller = await db.select().from(users).where(eq(users.id, parseInt(sellerId))).limit(1);
      const buyer = await db.select().from(users).where(eq(users.id, parseInt(buyerId))).limit(1);

      if (product[0] && seller[0] && buyer[0]) {
        // Update seller stars
        await db
          .update(users)
          .set({ stars: sql`stars + 1` })
          .where(eq(users.id, parseInt(sellerId)));

        // Update product status
        await db
          .update(products)
          .set({ status: 'purchased', buyerId: parseInt(buyerId) })
          .where(eq(products.id, parseInt(productId)));

        // Store email notification
        await db.insert(emails).values({
          toEmail: seller[0].email,
          ccEmail: 'abhirampanicker@gmail.com',
          subject: 'New Purchase Request - MyExtraToYou',
          body: `Hello ${seller[0].name},

Great news! ${buyer[0].name} is interested in purchasing your book "${product[0].name}".

Product Details:
- Book: ${product[0].name}
- Price: ₹${product[0].price}
- Language: ${product[0].language}
- Topic: ${product[0].topic}

Buyer Contact:
- Name: ${buyer[0].name}
- Email: ${buyer[0].email}
- Phone: ${buyer[0].mobile}
- Location: ${buyer[0].state}, ${buyer[0].district}

Please contact the buyer directly to arrange the transaction.

Best regards,
MyExtraToYou Team`,
          sent: true
        });
      }

      res.json({ success: true, transaction: newTransaction[0] });
    } 
    else if (action === 'reject') {
      // Create rejection record
      const newRejection = await db.insert(rejections).values({
        productId: parseInt(productId),
        sellerId: parseInt(sellerId),
        buyerId: parseInt(buyerId),
        reason,
        details
      }).returning();

      // Get seller details
      const seller = await db.select().from(users).where(eq(users.id, parseInt(sellerId))).limit(1);
      const newRejections = (seller[0].rejections || 0) + 1;
      const newStars = Math.max(0, (seller[0].stars || 0) - 1);
      const shouldBan = newRejections >= 5;

      // Update seller stats
      await db
        .update(users)
        .set({ 
          stars: newStars, 
          rejections: newRejections,
          banned: shouldBan,
          banDate: shouldBan ? new Date() : null
        })
        .where(eq(users.id, parseInt(sellerId)));

      // Update product status
      await db
        .update(products)
        .set({ status: 'rejected', rejectedBy: parseInt(buyerId) })
        .where(eq(products.id, parseInt(productId)));

      // Get product and buyer details for admin email
      const product = await db.select().from(products).where(eq(products.id, parseInt(productId))).limit(1);
      const buyer = await db.select().from(users).where(eq(users.id, parseInt(buyerId))).limit(1);

      if (product[0] && buyer[0] && seller[0]) {
        // Send feedback email to admin
        await db.insert(emails).values({
          toEmail: 'abhirampanicker@gmail.com',
          ccEmail: null,
          subject: 'Product Rejection Feedback - MyExtraToYou',
          body: `Product Rejection Feedback

Seller: ${seller[0].name} (${seller[0].email})
Product: ${product[0].name}
Rejected by: ${buyer[0].name} (${buyer[0].email})

Reason: ${reason}
Details: ${details}

Seller Stats:
- Current Stars: ${newStars}
- Total Rejections: ${newRejections}
- Account Status: ${shouldBan ? 'BANNED' : 'Active'}

Transaction Date: ${new Date().toLocaleString()}

---
MyExtraToYou Admin Panel`,
          sent: true
        });
      }

      res.json({ success: true, rejection: newRejection[0], sellerBanned: shouldBan });
    }
    else {
      res.status(400).json({ success: false, message: 'Invalid action' });
    }
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Rejections endpoints
app.post('/api/rejections', async (req, res) => {
  try {
    const { productId, sellerId, buyerId, reason, details } = req.body;
    
    const newRejection = await db.insert(rejections).values({
      productId: parseInt(productId),
      sellerId: parseInt(sellerId),
      buyerId: parseInt(buyerId),
      reason,
      details
    }).returning();

    // Update seller stars and rejections
    const seller = await db.select().from(users).where(eq(users.id, parseInt(sellerId))).limit(1);
    const newRejections = (seller[0].rejections || 0) + 1;
    const newStars = Math.max(0, (seller[0].stars || 0) - 1);
    const shouldBan = newRejections >= 5;

    await db
      .update(users)
      .set({ 
        stars: newStars, 
        rejections: newRejections,
        banned: shouldBan,
        banDate: shouldBan ? new Date() : null
      })
      .where(eq(users.id, parseInt(sellerId)));

    res.json({ success: true, rejection: newRejection[0], banned: shouldBan });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Emails endpoint
app.post('/api/emails', async (req, res) => {
  try {
    const { toEmail, ccEmail, subject, body } = req.body;
    
    const newEmail = await db.insert(emails).values({
      toEmail,
      ccEmail,
      subject,
      body,
      sent: true
    }).returning();

    res.json({ success: true, email: newEmail[0] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Help requests endpoint
app.post('/api/help-requests', async (req, res) => {
  try {
    const { userId, problemType, problemTitle, problemDetails, userAgent } = req.body;
    
    const newHelpRequest = await db.insert(helpRequests).values({
      userId: userId ? parseInt(userId) : null,
      problemType,
      problemTitle,
      problemDetails,
      userAgent,
      resolved: false
    }).returning();

    res.json({ success: true, helpRequest: newHelpRequest[0] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Health check
app.get('/api/health', (req, res) => {
  res.json({ success: true, message: 'API server is running' });
});

app.listen(port, '0.0.0.0', () => {
  console.log(`API server running on port ${port}`);
});