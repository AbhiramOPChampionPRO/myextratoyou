import express from 'express';
import cors from 'cors';
import { Pool, neonConfig } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-serverless';
import { users, products, transactions, emails, rejections, helpRequests } from '../shared/schema';
import { eq, sql } from 'drizzle-orm';
import ws from 'ws';

neonConfig.webSocketConstructor = ws;

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL must be set");
}

const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const db = drizzle(pool, { schema: { users, products, transactions, emails, rejections, helpRequests } });

const app = express();
const port = 3001;

app.use(cors());
app.use(express.json());

// Health check
app.get('/api/health', (req, res) => {
  res.json({ success: true, message: 'API server is running' });
});

// Users endpoints
app.post('/api/users', async (req, res) => {
  try {
    const { name, email, password, mobile, state, district } = req.body;
    
    // Check if user already exists
    const existingUser = await db.select().from(users).where(eq(users.email, email)).limit(1);
    
    if (existingUser.length > 0) {
      return res.json({ success: true, user: existingUser[0], message: 'User logged in' });
    }

    // Create new user
    const newUser = await db.insert(users).values({
      name,
      email,
      password,
      mobile,
      state,
      district,
      stars: 0,
      rejections: 0,
      banned: false
    }).returning();

    res.json({ success: true, user: newUser[0], message: 'User created' });
  } catch (error: any) {
    console.error('User creation error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

app.get('/api/users/:email', async (req, res) => {
  try {
    const { email } = req.params;
    const user = await db.select().from(users).where(eq(users.email, email)).limit(1);
    
    if (user.length === 0) {
      return res.status(404).json({ success: false, error: 'User not found' });
    }

    res.json({ success: true, user: user[0] });
  } catch (error: any) {
    console.error('User fetch error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

app.put('/api/users/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const updates = req.body;
    
    const updatedUser = await db
      .update(users)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(users.id, parseInt(id)))
      .returning();

    res.json({ success: true, user: updatedUser[0] });
  } catch (error: any) {
    console.error('User update error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// Products endpoints
app.post('/api/products', async (req, res) => {
  try {
    const { name, language, topic, price, rating, place, images, sellerId } = req.body;
    
    const newProduct = await db.insert(products).values({
      name,
      language,
      topic,
      price: parseInt(price),
      rating: parseInt(rating),
      place,
      images: JSON.stringify(images),
      sellerId: parseInt(sellerId)
    }).returning();

    res.json({ success: true, product: newProduct[0] });
  } catch (error: any) {
    console.error('Product creation error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

app.get('/api/products', async (req, res) => {
  try {
    const allProducts = await db
      .select()
      .from(products)
      .leftJoin(users, eq(products.sellerId, users.id));

    const formattedProducts = allProducts.map(row => ({
      ...row.products,
      images: JSON.parse(row.products.images || '[]'),
      seller: row.users
    }));

    res.json({ success: true, products: formattedProducts });
  } catch (error: any) {
    console.error('Products fetch error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

app.put('/api/products/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const updates = req.body;
    
    const updatedProduct = await db
      .update(products)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(products.id, parseInt(id)))
      .returning();

    res.json({ success: true, product: updatedProduct[0] });
  } catch (error: any) {
    console.error('Product update error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

app.delete('/api/products/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    await db.delete(products).where(eq(products.id, parseInt(id)));
    
    res.json({ success: true, message: 'Product deleted' });
  } catch (error: any) {
    console.error('Product deletion error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// Transactions endpoints
app.post('/api/transactions', async (req, res) => {
  try {
    const { productId, sellerId, buyerId, status } = req.body;
    
    const newTransaction = await db.insert(transactions).values({
      productId: parseInt(productId),
      sellerId: parseInt(sellerId),
      buyerId: parseInt(buyerId),
      status
    }).returning();

    // Update seller stars if purchased
    if (status === 'purchased') {
      await db
        .update(users)
        .set({ stars: sql`${users.stars} + 1` })
        .where(eq(users.id, parseInt(sellerId)));
    }

    res.json({ success: true, transaction: newTransaction[0] });
  } catch (error: any) {
    console.error('Transaction creation error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// Rejections endpoints
app.post('/api/rejections', async (req, res) => {
  try {
    const { productId, sellerId, buyerId, reason, details } = req.body;
    
    const newRejection = await db.insert(rejections).values({
      productId: parseInt(productId),
      sellerId: parseInt(sellerId),
      buyerId: parseInt(buyerId),
      reason,
      details
    }).returning();

    // Get current seller data
    const seller = await db.select().from(users).where(eq(users.id, parseInt(sellerId))).limit(1);
    if (seller.length > 0) {
      const newRejections = (seller[0].rejections || 0) + 1;
      const newStars = Math.max(0, (seller[0].stars || 0) - 1);
      const shouldBan = newRejections >= 5;

      await db
        .update(users)
        .set({ 
          stars: newStars, 
          rejections: newRejections,
          banned: shouldBan,
          banDate: shouldBan ? new Date() : null
        })
        .where(eq(users.id, parseInt(sellerId)));

      res.json({ success: true, rejection: newRejection[0], banned: shouldBan });
    } else {
      res.json({ success: true, rejection: newRejection[0], banned: false });
    }
  } catch (error: any) {
    console.error('Rejection creation error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// Emails endpoint
app.post('/api/emails', async (req, res) => {
  try {
    const { toEmail, ccEmail, subject, body } = req.body;
    
    const newEmail = await db.insert(emails).values({
      toEmail,
      ccEmail,
      subject,
      body,
      sent: true
    }).returning();

    res.json({ success: true, email: newEmail[0] });
  } catch (error: any) {
    console.error('Email creation error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// Help requests endpoint
app.post('/api/help-requests', async (req, res) => {
  try {
    const { userId, problemType, problemTitle, problemDetails, userAgent } = req.body;
    
    const newHelpRequest = await db.insert(helpRequests).values({
      userId: userId ? parseInt(userId) : null,
      problemType,
      problemTitle,
      problemDetails,
      userAgent,
      resolved: false
    }).returning();

    res.json({ success: true, helpRequest: newHelpRequest[0] });
  } catch (error: any) {
    console.error('Help request creation error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

app.listen(port, '0.0.0.0', () => {
  console.log(`MyExtraToYou API server running on port ${port}`);
});