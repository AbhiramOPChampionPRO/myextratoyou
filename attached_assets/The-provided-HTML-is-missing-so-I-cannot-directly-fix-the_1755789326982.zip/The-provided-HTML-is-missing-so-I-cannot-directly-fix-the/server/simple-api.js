const express = require('express');
const cors = require('cors');

const app = express();
const port = 3001;

app.use(cors());
app.use(express.json());
app.use(express.static('.')); // Serve static files from root

// Simple health check
app.get('/api/health', (req, res) => {
  res.json({ success: true, message: 'API server is running' });
});

// Simple users endpoint for testing
app.post('/api/users', (req, res) => {
  console.log('User registration/login:', req.body);
  // Simulate user creation/login
  const user = {
    id: Math.floor(Math.random() * 1000),
    ...req.body,
    stars: 0,
    rejections: 0,
    banned: false
  };
  res.json({ success: true, user, message: 'User processed' });
});

app.get('/api/users/:email', (req, res) => {
  console.log('Get user by email:', req.params.email);
  // Simulate user lookup
  const user = {
    id: 1,
    name: 'Test User',
    email: req.params.email,
    stars: 5,
    rejections: 0,
    banned: false
  };
  res.json({ success: true, user });
});

// Products endpoint
app.post('/api/products', (req, res) => {
  console.log('Product creation:', req.body);
  const product = {
    id: Math.floor(Math.random() * 1000),
    ...req.body
  };
  res.json({ success: true, product });
});

app.get('/api/products', (req, res) => {
  console.log('Get all products');
  // Return sample products
  const products = [
    {
      id: 1,
      name: 'Sample Book',
      language: 'English',
      topic: 'Fiction',
      price: 10,
      rating: 4,
      place: 'Sample City',
      images: ['https://via.placeholder.com/150'],
      seller: { id: 2, name: 'Sample Seller', stars: 5, banned: false }
    }
  ];
  res.json({ success: true, products });
});

// Email endpoint
app.post('/api/emails', (req, res) => {
  console.log('Email sent:', req.body);
  res.json({ success: true, email: { id: 1, sent: true } });
});

// Help request endpoint
app.post('/api/help-requests', (req, res) => {
  console.log('Help request:', req.body);
  res.json({ success: true, helpRequest: { id: 1 } });
});

app.listen(port, '0.0.0.0', () => {
  console.log(`Simple API server running on port ${port}`);
});